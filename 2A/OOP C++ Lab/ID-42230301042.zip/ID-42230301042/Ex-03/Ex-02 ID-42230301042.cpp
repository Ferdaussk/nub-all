#include <iostream>

int main() {
    int length = 8;
    int width = 6;
    int area = length * width;
    std::cout << "Area of the rectangle: " << area << std::endl;
    return 0;
}
