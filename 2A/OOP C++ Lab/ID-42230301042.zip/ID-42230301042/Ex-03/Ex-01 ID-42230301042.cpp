#include <iostream>

int main() {
    int num1 = 5;
    int num2 = 7;
    int sum = num1 + num2;
    std::cout << "Sum: " << sum << std::endl;
    return 0;
}
