#include <iostream>

int main() {
    bool isStudent = true;
    int studentId = 12345;

    std::cout << "Is Student: " << isStudent << std::endl;
    std::cout << "Student ID: " << studentId << std::endl;

    return 0;
}
