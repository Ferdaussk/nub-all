#include <iostream>
#include <string>

int main() {
    int height = 175;
    double weight = 68.5;
    std::string eyeColor = "Brown";

    std::cout << "Height: " << height << std::endl;
    std::cout << "Weight: " << weight << std::endl;
    std::cout << "Eye Color: " << eyeColor << std::endl;

    return 0;
}
