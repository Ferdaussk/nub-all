#include <iostream>

int main() {
    std::cout << "YourName starts coding in C++!" << std::endl;
    return 0;
}
