#include <iostream>

int main() {
    std::cout << "Learning C++ is fun!" << std::endl;
    return 0;
}
