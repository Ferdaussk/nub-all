#include <iostream>

int main() {
    for (int i = 1; i <= 5; ++i) {
        std::cout << i * i << " ";
    }

    std::cout << std::endl;

    return 0;
}
