#include <iostream>
#include <string>

int main() {
    std::string firstName = "John";
    std::string lastName = "Doe";

    std::cout << "Full Name: " << firstName + " " + lastName << std::endl;

    return 0;
}
