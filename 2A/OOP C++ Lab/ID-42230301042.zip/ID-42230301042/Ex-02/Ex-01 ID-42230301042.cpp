#include <iostream>

int main() {
    int num1 = 12;
    int num2 = 4;

    std::cout << "Multiplication: " << num1 * num2 << std::endl;
    std::cout << "Division: " << num1 / num2 << std::endl;

    return 0;
}
