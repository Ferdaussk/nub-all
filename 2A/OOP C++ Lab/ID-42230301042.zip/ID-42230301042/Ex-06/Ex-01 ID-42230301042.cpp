#include <iostream>

int main() {
    int dividend = 15;
    int divisor = 4;

    int remainder = dividend % divisor;

    std::cout << "Remainder of dividing 15 by 4: " << remainder << std::endl;

    return 0;
}
