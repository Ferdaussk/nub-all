#include <iostream>

int main() {
    int variable = 5;

    // Increment
    ++variable;
    std::cout << "After Increment: " << variable << std::endl;

    // Decrement
    --variable;
    std::cout << "After Decrement: " << variable << std::endl;

    return 0;
}
