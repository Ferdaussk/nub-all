#include <stdio.h>

int main() {
    printf("Size of int in byte(s) = %lu\n", sizeof(int));
    printf("Size of float in byte(s) = %lu\n", sizeof(float));
    printf("Size of double in byte(s) = %lu\n", sizeof(double));
    printf("Size of char in byte(s) = %lu\n", sizeof(char));

    return 0;
}
