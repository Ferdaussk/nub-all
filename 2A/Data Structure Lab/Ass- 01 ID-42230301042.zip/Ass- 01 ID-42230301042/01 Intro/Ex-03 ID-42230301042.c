#include <stdio.h>

int main() {
    printf("The question is - \"How to write a\n\\comment/ in C programming language?\"\n");
    return 0;
}
