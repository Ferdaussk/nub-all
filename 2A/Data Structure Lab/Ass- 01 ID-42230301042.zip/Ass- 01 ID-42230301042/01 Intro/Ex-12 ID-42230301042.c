#include <stdio.h>

#define PI 3.14
#define GOLDEN_RATIO 1.62

int main() {
    printf("The value of pi: %.2f\n", PI);
    printf("The value of golden ratio: %.2f\n", GOLDEN_RATIO);

    return 0;
}
