#include <stdio.h>

int main() {
    printf("Hello World.\nThis is my first program.\tC is fun.\n");
    return 0;
}
